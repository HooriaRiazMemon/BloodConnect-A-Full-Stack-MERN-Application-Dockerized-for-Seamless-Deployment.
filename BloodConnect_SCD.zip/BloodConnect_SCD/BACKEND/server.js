const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');

const authRoutes = require('./routes/authRoutes');
const donorRoutes = require('./routes/donorRoutes'); 
const requestRoutes = require('./routes/requestRoutes'); 
const receiverRoutes = require('./routes/receiver'); 
dotenv.config();

const app = express();

app.use(cors()); 
app.use(express.json());
const MONGO_URI = process.env.MONGO_URI; 
const PORT = process.env.PORT || 5000;

if (!MONGO_URI) {
    console.error("ERROR: MONGO_URI is not defined in the .env file!");
    process.exit(1); 
}

mongoose.connect(MONGO_URI)
    .then(() => {
        console.log(' MongoDB successfully connected!');
        
        app.listen(PORT, '0.0.0.0', () => {
    console.log(` Server running on port ${PORT}`);
});
    })
    .catch(err => {
        console.error(' MongoDB connection error:', err.message);
        console.error('Please check your MONGO_URI in the .env file.');
        process.exit(1);
    });



app.get('/', (req, res) => {
    res.send('Welcome to BloodConnect Backend! 🩸');
});

app.use('/api/auth', authRoutes); 
app.use('/api/donor', donorRoutes); 
app.use('/api/requests', requestRoutes); 
app.use('/api/receiver', receiverRoutes); 
app.use((req, res, next) => {
    res.status(404).send("Error 404: Route Not Found.");
});