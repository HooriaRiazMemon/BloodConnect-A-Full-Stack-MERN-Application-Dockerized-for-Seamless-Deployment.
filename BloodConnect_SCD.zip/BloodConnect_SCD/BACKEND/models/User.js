const mongoose = require('mongoose');


const healthDetailsSchema = new mongoose.Schema({
    bloodGroup: {
        type: String,
        required: true,
        enum: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'], 
    },
    bloodPressure: { type: String, default: 'N/A' },
    heartRate: { type: Number, default: 0 },
    weight: { type: Number, default: 0 }, 
    height: { type: Number, default: 0 }, 
   
    existingConditions: {
        type: [String], 
        default: [],
    },
   
    recentSurgery: { type: Boolean, default: false },
    recentTattoo: { type: Boolean, default: false },
    isSmoking: { type: Boolean, default: false },
   
    isEligible: {
        type: Boolean,
        default: false, 
    },
    lastDonationDate: { type: Date, default: null }, 
});


const UserSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
   
    role: {
        type: String,
        required: true,
        enum: ['Donor', 'Receiver'],
    },
   
    city: { type: String, required: true },
    contactNumber: { type: String, required: true },
   
    isAvailable: {
        type: Boolean,
        default: true,
    },
   
    healthProfile: {
        type: healthDetailsSchema,
        required: function() {
            return this.role === 'Donor';
        }
    },
   
    createdAt: { type: Date, default: Date.now }
});


module.exports = mongoose.model('User', UserSchema);