const mongoose = require('mongoose');

const RequestSchema = new mongoose.Schema({
    receiverId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', 
        required: true,
    },
    receiverName: {
        type: String,
        required: true,
    },
    
    bloodGroup: {
        type: String,
        required: true,
        enum: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
    },
    requiredUnits: {
        type: Number, 
        required: true,
    },
    hospitalName: {
        type: String,
        required: true,
    },
    city: {
        type: String,
        required: true,
    },
    contactPhone: {
        type: String,
        required: true,
    },
    
    urgency: {
        type: String,
        enum: ['Normal', 'Urgent', 'Critical'], 
        default: 'Normal',
    },
    status: {
        type: String,
        enum: ['Pending', 'Fulfilled', 'Cancelled'],
        default: 'Pending',
    },
    
    donorResponses: [{
        donorId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
        },
        donorName: {
            type: String,
        },
        contactNumber: {
            type: String,
        },
        respondedAt: {
            type: Date,
            default: Date.now,
        },
    }],
    
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Request', RequestSchema);