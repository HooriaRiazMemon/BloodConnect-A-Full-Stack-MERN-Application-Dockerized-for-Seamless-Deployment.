
const express = require('express');
const router = express.Router();
const User = require('../models/User'); 
const auth = require('../middleware/auth'); 


router.get('/me', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user.id).select('-password');
        
        if (!user) {
            return res.status(404).json({ msg: 'Receiver user not found' });
        }
       
        res.json({ 
            user: {
                _id: user._id,
                name: user.name,
                email: user.email,
                role: user.role, 
                city: user.city,
                contactNumber: user.contactNumber,
            }
        }); 

    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});


module.exports = router;