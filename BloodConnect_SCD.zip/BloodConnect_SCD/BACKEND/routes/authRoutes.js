const express = require('express');
const router = express.Router();
const User = require('../models/User'); 
const bcrypt = require('bcryptjs'); 
const jwt = require('jsonwebtoken'); 
router.post('/register', async (req, res) => {
    const { name, email, password, role, city, contactNumber, healthProfile } = req.body;
    
    if (!name || !email || !password || !role || !city || !contactNumber) {
        return res.status(400).json({ msg: 'Please enter all required fields: name, email, password, role, city, and contactNumber.' });
    }

    try {
        let user = await User.findOne({ email });

        if (user) {
            return res.status(400).json({ msg: 'User already exists with this email.' });
        }

        let userData = {
            name,
            email,
            password, 
            role,
            city,
            contactNumber,
        };

        if (role === 'Donor') {
            if (!healthProfile) {
                 return res.status(400).json({ msg: 'Donor registration requires a healthProfile object.' });
            }
            userData.healthProfile = healthProfile;
        }

        user = new User(userData);
        
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(password, salt);

        await user.save();

        const payload = {
            user: {
                id: user.id,
                role: user.role,
                city: user.city 
            }
        };

        jwt.sign(
            payload,
            process.env.JWT_SECRET,
            { expiresIn: '1h' }, 
            (err, token) => {
                if (err) throw err;
                res.status(201).json({ 
                    msg: 'User registered successfully!', 
                    token, 
                    user: {
                        id: user.id,
                        name: user.name,
                        email: user.email,
                        role: user.role
                    }
                });
            }
        );

    } catch (err) {
        console.error(err.message);
        if (err.name === 'ValidationError') {
             return res.status(400).json({ msg: err.message });
        }
        res.status(500).send('Server Error');
    }
});


router.post('/login', async (req, res) => {
    console.log('Login attempt Body received:', req.body);
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ msg: 'Please enter both email and password.' });
    }

    try {
        let user = await User.findOne({ email });

        if (!user) {
            return res.status(400).json({ msg: 'Invalid Credentials (User not found)' });
        }

        const isMatch = await bcrypt.compare(password, user.password);

        if (!isMatch) {
            return res.status(400).json({ msg: 'Invalid Credentials (Password mismatch)' });
        }

        const payload = {
            user: {
                id: user.id,
                role: user.role,
            }
        };

        jwt.sign(
            payload,
            process.env.JWT_SECRET, 
            { expiresIn: '1h' }, 
            (err, token) => {
                if (err) throw err;
                res.json({ 
                    token,
                    role: user.role,
                    user: {
                        id: user.id,
                        name: user.name,
                        email: user.email,
                        role: user.role,
                        city: user.city
                    }
                });
            }
        );

    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

module.exports = router;