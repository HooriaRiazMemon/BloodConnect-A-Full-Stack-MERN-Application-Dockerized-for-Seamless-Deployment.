const express = require('express');
const router = express.Router();
const Request = require('../models/Request');
const User = require('../models/User');
const auth = require('../middleware/auth');
const { getRecipientGroups } = require('../utils/compatibility');


router.post('/', auth, async (req, res) => {
    if (req.user.role !== 'Receiver') {
        return res.status(403).json({ msg: 'Only Receivers can create blood requests.' });
    }


    const { bloodGroup, requiredUnits, hospitalName, city, contactPhone, urgency } = req.body;


    try {
        const receiver = await User.findById(req.user.id);
       
        const newRequest = new Request({
            receiverId: req.user.id,
            receiverName: receiver.name,
            bloodGroup,
            requiredUnits,
            hospitalName,
            city: (city || receiver.city).trim(),
            contactPhone: contactPhone || receiver.contactNumber,
            urgency: urgency || 'Normal',
        });


        const request = await newRequest.save();
        res.json({ msg: 'Blood request created successfully.', request });
    } catch (err) {
        console.error("Create Error:", err.message);
        res.status(500).json({ msg: 'Server Error', error: err.message });
    }
});


router.get('/active', auth, async (req, res) => {
    try {
        const currentUser = await User.findById(req.user.id);
        if (currentUser.role !== 'Donor') return res.status(403).json({ msg: 'Donors only.' });


        let query = {
            status: 'Pending',
            city: { $regex: new RegExp(currentUser.city.trim(), 'i') }
        };
       
        if (currentUser.healthProfile?.bloodGroup) {
            const matchingGroups = getRecipientGroups(currentUser.healthProfile.bloodGroup);
            if (matchingGroups?.length > 0) query.bloodGroup = { $in: matchingGroups };
        }


        const requests = await Request.find(query).sort({ urgency: -1, createdAt: -1 }).select('-donorResponses');
        res.json(requests);
    } catch (err) {
        res.status(500).json({ msg: 'Server Error' });
    }
});


router.put('/:id/status', auth, async (req, res) => {
    try {
        let request = await Request.findById(req.params.id);
        if (!request) return res.status(404).json({ msg: 'Request not found' });


        if (request.receiverId.toString() !== req.user.id) {
            return res.status(401).json({ msg: 'User not authorized' });
        }


        request.status = req.body.status;
        await request.save();
        res.json({ msg: `Request marked as ${req.body.status}` });
    } catch (err) {
        res.status(500).send('Server Error');
    }
});


router.delete('/:id', auth, async (req, res) => {
    try {
        const request = await Request.findById(req.params.id);
        if (!request) return res.status(404).json({ msg: 'Request not found' });


        if (request.receiverId.toString() !== req.user.id) {
            return res.status(401).json({ msg: 'User not authorized' });
        }


        await Request.findByIdAndDelete(req.params.id);
        res.json({ msg: 'Request removed successfully' });
    } catch (err) {
        res.status(500).send('Server Error');
    }
});


router.get('/my', auth, async (req, res) => {
    try {
        const myRequests = await Request.find({ receiverId: req.user.id }).sort({ createdAt: -1 });
        res.json(myRequests);
    } catch (err) {
        res.status(500).send('Server Error');
    }
});


router.put('/respond/:id', auth, async (req, res) => {
    try {
        const donor = await User.findById(req.user.id);
        const request = await Request.findById(req.params.id);
       
        const alreadyResponded = request.donorResponses.some(r => r.donorId.toString() === req.user.id);
        if (alreadyResponded) return res.status(400).json({ msg: 'Already responded.' });


        request.donorResponses.unshift({
            donorId: req.user.id,
            donorName: donor.name,
            contactNumber: donor.contactNumber,
        });


        await request.save();
        res.json({ msg: 'Response sent!' });
    } catch (err) {
        res.status(500).send('Server Error');
    }
});


module.exports = router;

