const express = require('express');
const router = express.Router();
const User = require('../models/User'); 
const auth = require('../middleware/auth'); 

const MIN_WEIGHT_KG = 50;
const MIN_LAST_DONATION_DAYS = 90; 

const calculateEligibility = (user) => {
    if (user.role !== 'Donor' || !user.healthProfile) {
        return { isEligible: false, reason: 'Not registered as a Donor or missing health profile.' };
    }
    
    const profile = user.healthProfile;
    const reasons = [];
    let isEligible = true;

    if (profile.weight < MIN_WEIGHT_KG) {
        isEligible = false;
        reasons.push(`Weight must be at least ${MIN_WEIGHT_KG} kg.`);
    }

    const seriousConditions = ['HIV', 'Heart Disease', 'Hepatitis'];
    if (profile.existingConditions.some(condition => seriousConditions.includes(condition))) {
        isEligible = false;
        reasons.push('Existing serious medical conditions make you ineligible.');
    }
    
    if (profile.recentSurgery || profile.recentTattoo) {
        isEligible = false;
        reasons.push('Recent surgery or tattoo may require a waiting period.');
    }
    
    if (profile.lastDonationDate) {
        const lastDonation = new Date(profile.lastDonationDate);
        const today = new Date();
        const diffTime = Math.abs(today - lastDonation);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays < MIN_LAST_DONATION_DAYS) {
            isEligible = false;
            const daysLeft = MIN_LAST_DONATION_DAYS - diffDays;
            reasons.push(`You must wait ${daysLeft} more days since your last donation (${MIN_LAST_DONATION_DAYS} days minimum).`);
        }
    }
    
    if (user.healthProfile.isEligible !== isEligible) {
        user.healthProfile.isEligible = isEligible;
        user.save().catch(e => console.error('Error saving eligibility status:', e));
    }

    return { 
        isEligible, 
        reason: isEligible ? 'You are currently Eligible to donate.' : reasons.join(' | ') 
    };
};

router.get('/me', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user.id).select('-password'); 
        
        if (!user) {
            return res.status(404).json({ msg: 'User not found' });
        }
        
        if (user.role !== 'Donor') {
             return res.status(403).json({ msg: 'Access denied. Only Donors can view this profile.' });
        }
        
        const eligibility = calculateEligibility(user);

        res.json({ user, eligibility });
        
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});



router.get('/search', auth, async (req, res) => {
    if (req.user.role !== 'Receiver') {
        return res.status(403).json({ msg: 'Access denied. Only Receivers can search for Donors.' });
    }

    const { city, bloodGroup, name, availability } = req.query; 

    let query = { 
        role: 'Donor',
        'healthProfile.isEligible': true 
    }; 

    if (city) {
        // Case-insensitive city search 
        query.city = { $regex: new RegExp(city, 'i') }; 
    }

    if (bloodGroup) {
        query['healthProfile.bloodGroup'] = bloodGroup; 
    }

    if (name) {
        query.name = { $regex: new RegExp(name, 'i') }; 
    }

    if (availability && ['Available', 'Not Available'].includes(availability)) {
        query.availabilityStatus = availability;
    }
    
    try {
        const donors = await User.find(query)
            .select('name city contactNumber healthProfile.bloodGroup availabilityStatus'); 
        
        res.json(donors);
        
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

router.put('/:id', auth, async (req, res) => {
    const { weight, bloodGroup, lastDonationDate, existingConditions, recentSurgery, recentTattoo, isSmoking } = req.body;
    const userId = req.params.id;

    if (!weight || !bloodGroup) {
        return res.status(400).json({ msg: 'Weight and Blood Group are required fields.' });
    }

    try {
        const user = await User.findById(userId);

        if (!user || user.role !== 'Donor') {
            return res.status(404).json({ msg: 'Donor not found or unauthorized.' });
        }
        
        if (req.user.id.toString() !== userId) {
             return res.status(401).json({ msg: 'Not authorized to update this profile.' });
        }


        if (!user.healthProfile) {
            user.healthProfile = {}; 
        }

        user.healthProfile.weight = weight;
        user.healthProfile.bloodGroup = bloodGroup;
        user.healthProfile.lastDonationDate = lastDonationDate || null; 
        
        user.healthProfile.existingConditions = existingConditions || [];
        user.healthProfile.recentSurgery = recentSurgery || false;
        user.healthProfile.recentTattoo = recentTattoo || false;
        user.healthProfile.isSmoking = isSmoking || false;
        
        const eligibility = calculateEligibility(user);

        await user.save(); 
        res.json({ 
            msg: 'Health profile updated successfully!', 
            user: user,
            eligibility: eligibility
        });

    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error during profile update.');
    }
});

module.exports = router;