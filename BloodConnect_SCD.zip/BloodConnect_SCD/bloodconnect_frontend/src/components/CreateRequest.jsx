
import React, { useState } from 'react';
import API from '../services/api';
import { useAuth } from '../context/AuthContext';

const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const urgencies = ['Low', 'Medium', 'High', 'Critical'];

const CreateRequest = ({ onNewRequest }) => {
    const { user } = useAuth();
    const [formData, setFormData] = useState({
        bloodGroup: '',
        requiredUnits: 1,
        hospitalName: '',
        city: user?.city || '',
        contactPhone: user?.contactNumber || '',
        urgency: 'Medium',
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(null);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
        setError(null);
        setSuccess(null);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError(null);
        setSuccess(null);

        const payload = { ...formData, requiredUnits: Number(formData.requiredUnits) };

        try {
            const res = await API.post('/requests', payload);
            setSuccess('Blood request created successfully! Donors will be notified.');
            
            setFormData({
                bloodGroup: '', requiredUnits: 1, hospitalName: '', 
                city: user?.city || '', contactPhone: user?.contactNumber || '', urgency: 'Medium',
            });
            if (onNewRequest) onNewRequest(res.data.request);

        } catch (err) {
            console.error('Request Creation Error:', err);
            setError(err.response?.data?.msg || 'Failed to create request.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={styles.container}>
            <h3 style={styles.heading}>Create New Blood Request 🚨</h3>
            
            <form onSubmit={handleSubmit} style={styles.form}>
                <div style={styles.inputGroup}>
                    <label>Blood Group:</label>
                    <select name="bloodGroup" value={formData.bloodGroup} onChange={handleChange} required style={styles.input}>
                        <option value="">Select Group *</option>
                        {bloodGroups.map(group => <option key={group} value={group}>{group}</option>)}
                    </select>
                </div>
                
                <div style={styles.inputGroup}>
                    <label>Units Required:</label>
                    <input type="number" name="requiredUnits" min="1" value={formData.requiredUnits} onChange={handleChange} required style={styles.input} />
                </div>
                
                <div style={styles.inputGroup}>
                    <label>Hospital/Clinic Name:</label>
                    <input type="text" name="hospitalName" value={formData.hospitalName} onChange={handleChange} placeholder="Hospital Name" required style={styles.input} />
                </div>
                
                <div style={styles.inputGroup}>
                    <label>City (Donors Search Area):</label>
                    <input type="text" name="city" value={formData.city} onChange={handleChange} placeholder="City" required style={styles.input} />
                </div>

                <div style={styles.inputGroup}>
                    <label>Contact Number:</label>
                    <input type="text" name="contactPhone" value={formData.contactPhone} onChange={handleChange} placeholder="Contact Number" required style={styles.input} />
                </div>

                <div style={styles.inputGroup}>
                    <label>Urgency:</label>
                    <select name="urgency" value={formData.urgency} onChange={handleChange} required style={styles.input}>
                        {urgencies.map(u => <option key={u} value={u}>{u}</option>)}
                    </select>
                </div>

                {error && <p style={styles.error}>{error}</p>}
                {success && <p style={styles.success}>{success}</p>}

                <button type="submit" disabled={loading} style={styles.button}>
                    {loading ? 'Submitting...' : 'Submit Request'}
                </button>
            </form>
        </div>
    );
};

const styles = {
    container: {
        backgroundColor: '#2D2D2D', padding: '20px', borderRadius: '10px', 
        maxWidth: '400px', margin: '20px auto', color: 'white'
    },
    heading: { color: '#DC3545', borderBottom: '2px solid #555', paddingBottom: '10px', marginBottom: '20px' },
    form: { display: 'flex', flexDirection: 'column', gap: '15px' },
    inputGroup: { display: 'flex', flexDirection: 'column' },
    input: { padding: '10px', borderRadius: '5px', border: '1px solid #444', backgroundColor: '#3A3A3A', color: 'white' },
    button: { padding: '10px 15px', backgroundColor: '#DC3545', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer', marginTop: '10px' },
    error: { color: '#FF6347', fontWeight: 'bold' },
    success: { color: '#4CAF50', fontWeight: 'bold' },
};

export default CreateRequest;