// src/components/DonorProfile.jsx

import React, { useState, useEffect } from 'react';
import API from '../services/api';

const DonorProfile = () => {
    const [profile, setProfile] = useState(null);
    const [eligibility, setEligibility] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchProfile = async () => {
            try {
             
                const res = await API.get('/donor/me'); 
                setProfile(res.data.user);
                setEligibility(res.data.eligibility);
            } catch (err) {
                console.error('Profile Fetch Error:', err);
                setError(err.response?.data?.msg || 'Failed to fetch donor profile.');
            } finally {
                setLoading(false);
            }
        };

        fetchProfile();
    }, []);

    if (loading) return <p style={styles.loading}>Loading Profile...</p>;
    if (error) return <p style={styles.error}>Error: {error}</p>;
    if (!profile) return <p style={styles.error}>No profile data found.</p>;

    const isEligible = eligibility?.isEligible;
    const profileData = profile.healthProfile || {};

    return (
        <div style={styles.container}>
            <h3 style={styles.heading}>Your Donor Profile</h3>
            
            {/* Eligibility Card */}
            <div style={{ ...styles.card, ...(isEligible ? styles.eligibleCard : styles.ineligibleCard) }}>
                <h4 style={styles.cardHeading}>Donation Eligibility Status</h4>
                <p style={styles.statusText}>
                    **{isEligible ? 'CURRENTLY ELIGIBLE' : 'INELIGIBLE'}**
                </p>
                <p style={styles.reasonText}>
                    **Reason:** {eligibility?.reason || 'Profile check incomplete.'}
                </p>
            </div>
            
            {/* Profile Details */}
            <div style={styles.detailsGrid}>
                <p><strong>Name:</strong> {profile.name}</p>
                <p><strong>Email:</strong> {profile.email}</p>
                <p><strong>Contact:</strong> {profile.contactNumber}</p>
                <p><strong>City:</strong> {profile.city}</p>
                <p><strong>Blood Group:</strong> {profileData.bloodGroup || 'N/A'}</p>
                <p><strong>Last Donation:</strong> {profileData.lastDonationDate ? new Date(profileData.lastDonationDate).toLocaleDateString() : 'Never'}</p>
                <p><strong>Weight (kg):</strong> {profileData.weight || 'N/A'}</p>
                <p><strong>Conditions:</strong> {profileData.existingConditions?.join(', ') || 'None'}</p>
            </div>
        </div>
    );
};

// Minimal Styles
const styles = {
    container: {
        backgroundColor: '#3A3A3A', 
        padding: '25px', 
        borderRadius: '10px', 
        maxWidth: '700px', 
        margin: '20px auto', 
        color: 'white'
    },
    heading: {
        borderBottom: '2px solid #DC3545',
        paddingBottom: '10px',
        marginBottom: '20px',
        color: '#FFFFFF'
    },
    loading: { color: 'white', textAlign: 'center' },
    error: { color: '#FF6347', textAlign: 'center' },
    card: {
        padding: '15px',
        borderRadius: '8px',
        marginBottom: '25px',
        textAlign: 'center',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.4)'
    },
    eligibleCard: {
        backgroundColor: '#28a74550', 
        border: '1px solid #28a745',
    },
    ineligibleCard: {
        backgroundColor: '#dc354550', 
        border: '1px solid #dc3545',
    },
    cardHeading: { color: 'white', borderBottom: '1px dotted #888', paddingBottom: '5px' },
    statusText: { fontSize: '1.2em', margin: '10px 0', fontWeight: 'bold' },
    reasonText: { fontSize: '0.9em', color: '#CCCCCC' },
    detailsGrid: {
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '15px',
        textAlign: 'left'
    }
};

export default DonorProfile;