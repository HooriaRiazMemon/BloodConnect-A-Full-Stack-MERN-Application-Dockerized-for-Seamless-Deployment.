import React, { useState, useEffect } from 'react';
import API from '../services/api';

const DonorRequests = ({ isEligible, donorBloodGroup }) => {
    const [requests, setRequests] = useState([]);
    const [loading, setLoading] = useState(true);

    // Popup message state (like Login)
    const [message, setMessage] = useState(null);
    const [messageType, setMessageType] = useState(null); // success | error

    useEffect(() => {
        const fetchRequests = async () => {
            try {
                const res = await API.get('/requests/active');
                setRequests(res.data);
            } catch (err) {
                console.error("Error fetching requests", err);
                setMessageType('error');
                setMessage("Failed to load requests.");
            } finally {
                setLoading(false);
            }
        };

        fetchRequests();
    }, []);

    const handleHelp = async (requestId) => {
        if (!isEligible) {
            setMessageType('error');
            setMessage("You are not eligible to donate right now.");
            return;
        }

        try {
            await API.put(`/requests/respond/${requestId}`);
            setMessageType('success');
            setMessage("Response sent! Receiver can now see your contact details.");
        } catch (err) {
            setMessageType('error');
            setMessage(err.response?.data?.msg || "Failed to respond");
        }
    };

    if (loading) {
        return (
            <p style={{ textAlign: 'center', color: '#aaa' }}>
                Searching for matches...
            </p>
        );
    }

    return (
        <div>
            {/* MESSAGE POPUP (Like Login Error UI) */}
            {message && (
                <div
                    style={{
                        ...styles.messageBox,
                        backgroundColor:
                            messageType === 'success' ? '#1f7a3a' : '#7a1f1f'
                    }}
                >
                    {message}
                    <span
                        style={styles.closeBtn}
                        onClick={() => setMessage(null)}
                    >
                        ✖
                    </span>
                </div>
            )}

            <div style={styles.grid}>
                {requests.length === 0 ? (
                    <p style={styles.noData}>
                        No active matching requests found in your area.
                    </p>
                ) : (
                    requests.map(req => (
                        <div key={req._id} style={styles.card}>
                            <div style={styles.cardHeader}>
                                <span style={styles.bloodGroupBadge}>
                                    {req.bloodGroup}
                                </span>
                                <span
                                    style={{
                                        ...styles.urgencyTag,
                                        backgroundColor:
                                            req.urgency === 'Critical'
                                                ? '#ff4d4d'
                                                : '#f39c12'
                                    }}
                                >
                                    {req.urgency}
                                </span>
                            </div>

                            <div style={styles.cardBody}>
                                <h4 style={styles.hospitalName}>
                                    {req.hospitalName}
                                </h4>
                                <p style={styles.detailsText}>
                                    📍 {req.city}
                                </p>
                                <p style={styles.detailsText}>
                                    💉 Units Required:{' '}
                                    <strong>{req.requiredUnits}</strong>
                                </p>
                            </div>

                            <button
                                onClick={() => handleHelp(req._id)}
                                style={styles.helpBtn}
                                disabled={!isEligible}
                            >
                                I Want to Help
                            </button>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

// ---------------- STYLES ----------------
const styles = {
    messageBox: {
        padding: '12px 16px',
        borderRadius: '8px',
        marginBottom: '20px',
        color: '#fff',
        fontWeight: 'bold',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        boxShadow: '0 4px 10px rgba(0,0,0,0.4)'
    },
    closeBtn: {
        cursor: 'pointer',
        marginLeft: '15px',
        fontWeight: 'bold'
    },
    grid: {
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
        gap: '20px',
        marginTop: '20px'
    },
    card: {
        backgroundColor: '#1e1e1e',
        borderRadius: '15px',
        padding: '20px',
        border: '1px solid #333',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        boxShadow: '0 4px 15px rgba(0,0,0,0.3)'
    },
    cardHeader: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '15px'
    },
    bloodGroupBadge: {
        backgroundColor: '#e74c3c',
        color: 'white',
        padding: '5px 12px',
        borderRadius: '8px',
        fontWeight: 'bold',
        fontSize: '1.2rem'
    },
    urgencyTag: {
        color: 'white',
        padding: '3px 10px',
        borderRadius: '5px',
        fontSize: '11px',
        fontWeight: 'bold',
        textTransform: 'uppercase'
    },
    cardBody: {
        marginBottom: '20px'
    },
    hospitalName: {
        color: '#ffffff',
        margin: '0 0 10px 0',
        fontSize: '1.1rem',
        textTransform: 'capitalize'
    },
    detailsText: {
        color: '#bbb',
        margin: '5px 0',
        fontSize: '0.9rem'
    },
    helpBtn: {
        backgroundColor: '#e74c3c',
        color: 'white',
        border: 'none',
        padding: '12px',
        borderRadius: '10px',
        cursor: 'pointer',
        fontWeight: 'bold',
        fontSize: '0.95rem'
    },
    noData: {
        color: '#aaa',
        gridColumn: '1 / -1',
        textAlign: 'center',
        padding: '40px'
    }
};

export default DonorRequests;
