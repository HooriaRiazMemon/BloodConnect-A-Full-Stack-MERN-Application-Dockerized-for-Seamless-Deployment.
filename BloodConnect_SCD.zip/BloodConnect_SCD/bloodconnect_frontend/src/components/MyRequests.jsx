// src/components/MyRequests.jsx

import React, { useState, useEffect, useCallback } from 'react';
import API from '../services/api';

const MyRequests = ({ newRequest }) => {
    const [requests, setRequests] = useState([]);
    const [loading, setLoading] = useState(true);

    const [message, setMessage] = useState(null);
    const [messageType, setMessageType] = useState(null); 

    const [expandedResponses, setExpandedResponses] = useState({});

    const fetchMyRequests = useCallback(async () => {
        setLoading(true);
        try {
            const res = await API.get('/requests/my');
            setRequests(res.data);
        } catch (err) {
            console.error('My Requests Fetch Error:', err);
            setMessageType('error');
            setMessage(err.response?.data?.msg || 'Failed to fetch your requests.');
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchMyRequests();
    }, [fetchMyRequests]);

    useEffect(() => {
        if (newRequest) {
            setRequests(prev => [
                newRequest,
                ...prev.filter(r => r._id !== newRequest._id)
            ]);
        }
    }, [newRequest]);

    const handleToggleResponses = async (requestId) => {
        if (expandedResponses[requestId]) {
            setExpandedResponses(prev => ({ ...prev, [requestId]: null }));
            return;
        }

        try {
            setExpandedResponses(prev => ({ ...prev, [requestId]: 'Loading...' }));
            const res = await API.get(`/requests/${requestId}/responses`);
            setExpandedResponses(prev => ({ ...prev, [requestId]: res.data }));
        } catch (err) {
            console.error('Responses Fetch Error:', err);
            setExpandedResponses(prev => ({
                ...prev,
                [requestId]: 'Error fetching responses.'
            }));
        }
    };

    // ✅ STATUS UPDATE WITH ALERT UI
    const handleStatusUpdate = async (requestId, newStatus) => {
        setMessageType('warning');
        setMessage(`Confirm: Mark this request as ${newStatus}? Click again to confirm.`);

        // Temporary confirmation logic
        if (message === `Confirm: Mark this request as ${newStatus}? Click again to confirm.`) {
            try {
                await API.put(`/requests/status/${requestId}`, { status: newStatus });

                setRequests(prev =>
                    prev.map(req =>
                        req._id === requestId ? { ...req, status: newStatus } : req
                    )
                );

                setMessageType('success');
                setMessage(`Request marked as ${newStatus}.`);
            } catch (err) {
                console.error('Status Update Error:', err);
                setMessageType('error');
                setMessage(
                    err.response?.data?.msg ||
                        `Failed to update status to ${newStatus}.`
                );
            }
        }
    };

    if (loading) return <p style={styles.loading}>Loading your requests...</p>;

    return (
        <div style={styles.container}>
            <h3 style={styles.heading}>Your Blood Request History</h3>

            {/* 🔔 ALERT MESSAGE UI */}
            {message && (
                <div
                    style={{
                        ...styles.messageBox,
                        backgroundColor:
                            messageType === 'success'
                                ? '#1f7a3a'
                                : messageType === 'warning'
                                ? '#8a6d1d'
                                : '#7a1f1f'
                    }}
                >
                    {message}
                    <span
                        style={styles.closeBtn}
                        onClick={() => setMessage(null)}
                    >
                        ✖
                    </span>
                </div>
            )}

            {requests.length === 0 && (
                <p style={styles.noRequests}>
                    You have not created any blood requests yet.
                </p>
            )}

            {requests.map(req => (
                <div
                    key={req._id}
                    style={{
                        ...styles.requestCard,
                        ...styles[req.status.toLowerCase()]
                    }}
                >
                    <div style={styles.cardHeader}>
                        <div style={styles.bloodGroupBox}>{req.bloodGroup}</div>
                        <div>
                            <p style={styles.title}>
                                {req.hospitalName} ({req.city})
                            </p>
                            <p style={styles.subTitle}>
                                Units: {req.requiredUnits} | Urgency: {req.urgency} | Status:{' '}
                                <strong>{req.status}</strong>
                            </p>
                        </div>
                    </div>

                    <p style={styles.contact}>Contact: {req.contactPhone}</p>

                    <div style={styles.actions}>
                        {req.status === 'Pending' ? (
                            <>
                                <button
                                    onClick={() => handleToggleResponses(req._id)}
                                    style={styles.actionButton}
                                >
                                    {expandedResponses[req._id]
                                        ? 'Hide Donors'
                                        : 'View Donor Responses'}
                                </button>

                                <button
                                    onClick={() =>
                                        handleStatusUpdate(req._id, 'Fulfilled')
                                    }
                                    style={{
                                        ...styles.actionButton,
                                        backgroundColor: '#28A745'
                                    }}
                                >
                                    Mark Fulfilled
                                </button>

                                <button
                                    onClick={() =>
                                        handleStatusUpdate(req._id, 'Cancelled')
                                    }
                                    style={{
                                        ...styles.actionButton,
                                        backgroundColor: '#6C757D'
                                    }}
                                >
                                    Mark Cancelled
                                </button>
                            </>
                        ) : (
                            <button
                                style={{
                                    ...styles.actionButton,
                                    backgroundColor: '#555'
                                }}
                                disabled
                            >
                                Status Locked
                            </button>
                        )}
                    </div>

                    {expandedResponses[req._id] && (
                        <div style={styles.responsesArea}>
                            {Array.isArray(expandedResponses[req._id]) ? (
                                expandedResponses[req._id].length > 0 ? (
                                    expandedResponses[req._id].map((res, index) => (
                                        <p key={index} style={styles.responseItem}>
                                            <strong>{res.donorName}</strong> (Contact:{' '}
                                            {res.contactNumber}) –{' '}
                                            {new Date(
                                                res.respondedAt
                                            ).toLocaleDateString()}
                                        </p>
                                    ))
                                ) : (
                                    <p style={{ color: '#F0AD4E' }}>
                                        No donors have responded yet.
                                    </p>
                                )
                            ) : (
                                <p>{expandedResponses[req._id]}</p>
                            )}
                        </div>
                    )}
                </div>
            ))}
        </div>
    );
};

const styles = {
    container: { maxWidth: '800px', margin: '20px auto' },
    heading: {
        color: '#FFFFFF',
        borderBottom: '2px solid #DC3545',
        paddingBottom: '10px',
        marginBottom: '20px'
    },
    loading: { color: 'white', textAlign: 'center' },
    noRequests: { color: '#AAAAAA', textAlign: 'center' },

    messageBox: {
        padding: '12px 16px',
        borderRadius: '8px',
        marginBottom: '20px',
        color: '#fff',
        fontWeight: 'bold',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        boxShadow: '0 4px 10px rgba(0,0,0,0.4)'
    },
    closeBtn: { cursor: 'pointer', marginLeft: '15px' },

    requestCard: {
        padding: '15px',
        borderRadius: '8px',
        marginBottom: '15px',
        borderLeft: '5px solid',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.5)'
    },
    pending: { backgroundColor: '#3A3A3A', borderLeftColor: '#F0AD4E' },
    fulfilled: { backgroundColor: '#3A3A3A', borderLeftColor: '#28A745' },
    cancelled: { backgroundColor: '#3A3A3A', borderLeftColor: '#DC3545' },

    cardHeader: { display: 'flex', alignItems: 'center', marginBottom: '10px' },
    bloodGroupBox: {
        backgroundColor: '#DC3545',
        color: 'white',
        padding: '10px',
        borderRadius: '5px',
        fontWeight: 'bold',
        fontSize: '1.2em',
        marginRight: '15px'
    },
    title: { fontSize: '1.1em', fontWeight: 'bold', margin: '0' },
    subTitle: { fontSize: '0.9em', color: '#CCCCCC', margin: '5px 0' },
    contact: { fontSize: '0.9em', color: '#F8F9FA', marginBottom: '10px' },

    actions: { display: 'flex', gap: '10px', marginTop: '10px' },
    actionButton: {
        padding: '8px 12px',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer',
        backgroundColor: '#3498DB',
        color: 'white',
        fontSize: '0.9em'
    },

    responsesArea: {
        marginTop: '15px',
        padding: '10px',
        backgroundColor: '#444444',
        borderRadius: '5px',
        borderLeft: '3px solid #F0AD4E'
    },
    responseItem: {
        margin: '5px 0',
        fontSize: '0.9em',
        color: '#E0E0E0'
    }
};

export default MyRequests;
