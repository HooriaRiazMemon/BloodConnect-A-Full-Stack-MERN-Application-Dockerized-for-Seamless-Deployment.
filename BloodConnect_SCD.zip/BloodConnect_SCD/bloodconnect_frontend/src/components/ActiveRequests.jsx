
import React, { useState, useEffect, useCallback } from 'react';
import API from '../services/api';
import { getRecipientGroups } from '../utils/compatibility'; 

const ActiveRequests = () => {
    const [requests, setRequests] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [responseMsg, setResponseMsg] = useState({}); 
    const fetchActiveRequests = useCallback(async () => {
        setLoading(true);
        setError(null);
        setResponseMsg({});
        try {
            const res = await API.get('/requests/active');
            setRequests(res.data);
        } catch (err) {
            console.error('Active Requests Fetch Error:', err);
            setError(err.response?.data?.msg || 'Failed to fetch active requests in your area.');
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchActiveRequests();
    }, [fetchActiveRequests]);

    const handleRespond = async (requestId) => {
        setResponseMsg(prev => ({ ...prev, [requestId]: 'Responding...' }));
        
        try {
            const res = await API.put(`/requests/respond/${requestId}`);
            
            setResponseMsg(prev => ({ 
                ...prev, 
                [requestId]: { type: 'success', msg: res.data.msg || 'Response recorded!' } 
            }));
            
            
            setRequests(prev => prev.filter(req => req._id !== requestId)); 

        } catch (err) {
            console.error('Response Error:', err);
            setResponseMsg(prev => ({ 
                ...prev, 
                [requestId]: { type: 'error', msg: err.response?.data?.msg || 'Failed to record response.' } 
            }));
        }
    };

    if (loading) return <p style={styles.loading}>Searching for urgent blood needs...</p>;
    if (error) return <p style={styles.error}>Error: {error}</p>;

    return (
        <div style={styles.container}>
            <h3 style={styles.heading}>Active Blood Requests Matching Your Profile ({requests.length})</h3>
            
            {requests.length === 0 && !loading && <p style={styles.noRequests}>No urgent requests found in your city that match your blood group.</p>}

            <div style={styles.requestsGrid}>
                {requests.map((req) => (
                    <div key={req._id} style={styles.requestCard}>
                        <div style={{...styles.urgencyBox, backgroundColor: styles.urgencyColors[req.urgency]}}>
                            {req.urgency}
                        </div>
                        <div style={styles.cardContent}>
                            <h4 style={styles.cardTitle}>{req.hospitalName}</h4>
                            <p style={styles.cardDetail}>**Blood Group Needed:** {req.bloodGroup}</p>
                            <p style={styles.cardDetail}>**Units:** {req.requiredUnits}</p>
                            <p style={styles.cardDetail}>**City:** {req.city}</p>
                            
                            {/* Response Feedback */}
                            {responseMsg[req._id] && typeof responseMsg[req._id] === 'object' && (
                                <p style={responseMsg[req._id].type === 'success' ? styles.success : styles.errorMsg}>
                                    {responseMsg[req._id].msg}
                                </p>
                            )}

                            {/* Action Button */}
                            <button 
                                onClick={() => handleRespond(req._id)} 
                                style={styles.respondButton} 
                                disabled={responseMsg[req._id] === 'Responding...'}
                            >
                                {responseMsg[req._id] === 'Responding...' ? 'Processing...' : 'I Can Donate'}
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

const styles = {
    container: { maxWidth: '1000px', margin: '20px auto' },
    heading: { color: '#FFFFFF', borderBottom: '2px solid #DC3545', paddingBottom: '10px', marginBottom: '20px' },
    loading: { color: 'white', textAlign: 'center' },
    error: { color: '#FF6347', textAlign: 'center' },
    noRequests: { color: '#AAAAAA', textAlign: 'center' },
    requestsGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '20px' },
    requestCard: { 
        backgroundColor: '#3A3A3A', padding: '15px', borderRadius: '8px', 
        position: 'relative', boxShadow: '0 4px 8px rgba(0, 0, 0, 0.4)'
    },
    urgencyBox: {
        position: 'absolute', top: 0, right: 0, 
        padding: '5px 10px', borderTopRightRadius: '8px', 
        color: 'white', fontWeight: 'bold', fontSize: '0.8em'
    },
    urgencyColors: {
        'Critical': '#DC3545',
        'High': '#F0AD4E',
        'Medium': '#3498DB',
        'Low': '#5CB85C'
    },
    cardContent: { paddingTop: '10px' },
    cardTitle: { color: '#F8F9FA', fontSize: '1.1em', borderBottom: '1px dotted #555', paddingBottom: '5px' },
    cardDetail: { margin: '5px 0', fontSize: '0.9em', color: '#E0E0E0' },
    respondButton: { 
        width: '100%', padding: '10px', backgroundColor: '#28A745', 
        color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer', 
        marginTop: '15px', fontWeight: 'bold' 
    },
    success: { color: '#4CAF50', fontWeight: 'bold', marginTop: '10px' },
    errorMsg: { color: '#FF6347', fontWeight: 'bold', marginTop: '10px' }
};

export default ActiveRequests;