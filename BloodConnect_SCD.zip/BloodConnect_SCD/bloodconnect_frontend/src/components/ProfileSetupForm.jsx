import React, { useState } from 'react';
import API from '../services/api';

const ProfileSetupForm = ({ onProfileUpdated, userId }) => {
    const [formData, setFormData] = useState({
        weight: '',
        bloodGroup: '',
        lastDonationDate: '',
        recentSurgery: false, 
        recentTattoo: false   
    });
    const [setupError, setSetupError] = useState(null);
    const [setupSuccess, setSetupSuccess] = useState(null);
    const [isSaving, setIsSaving] = useState(false);

    const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData({ 
            ...formData, 
            [name]: type === 'checkbox' ? checked : value 
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSaving(true);
        setSetupError(null);
        setSetupSuccess(null);

        if (formData.weight < 50) {
            setSetupError("Weight must be at least 50 kg to donate.");
            setIsSaving(false);
            return;
        }

        if (!userId) {
            setSetupError("User ID is missing. Please re-login.");
            setIsSaving(false);
            return;
        }

        try {
            const res = await API.put(`/donor/${userId}`, formData);
            if (res.status === 200) {
                setSetupSuccess("Profile updated successfully!");
                onProfileUpdated();
            }
        } catch (err) {
            const message = err.response?.data?.msg || 'Failed to save profile.';
            setSetupError(message);
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div style={styles.formContainer}>
            <h3 style={styles.heading}>Complete Your Donor Profile</h3>
            <p style={styles.subHeading}>
                Enter the required information for donation eligibility checks.
            </p>

            <form onSubmit={handleSubmit} style={styles.form}>
                {/* Weight */}
                <label style={styles.label}>
                    Weight (kg)
                    <input
                        type="number"
                        name="weight"
                        value={formData.weight}
                        onChange={handleChange}
                        required
                        min="1"
                        style={styles.input}
                    />
                </label>

                {/* Blood Group */}
                <label style={styles.label}>
                    Blood Group
                    <select
                        name="bloodGroup"
                        value={formData.bloodGroup}
                        onChange={handleChange}
                        required
                        style={styles.input}
                    >
                        <option value="">Select Blood Group</option>
                        {bloodGroups.map(group => (
                            <option key={group} value={group}>{group}</option>
                        ))}
                    </select>
                </label>

                {/* Last Donation */}
                <label style={styles.label}>
                    Last Donation Date
                    <input
                        type="date"
                        name="lastDonationDate"
                        value={formData.lastDonationDate}
                        onChange={handleChange}
                        style={styles.input}
                    />
                    <small style={styles.helperText}>Leave blank if you have never donated.</small>
                </label>

                {/* --- Risk Factor Checkboxes --- */}
                <div style={styles.checkboxContainer}>
                    <label style={styles.checkboxLabel}>
                        <input
                            type="checkbox"
                            name="recentSurgery"
                            checked={formData.recentSurgery}
                            onChange={handleChange}
                            style={styles.checkbox}
                        />
                        Recent Surgery (Last 6 months)
                    </label>

                    <label style={styles.checkboxLabel}>
                        <input
                            type="checkbox"
                            name="recentTattoo"
                            checked={formData.recentTattoo}
                            onChange={handleChange}
                            style={styles.checkbox}
                        />
                        Recent Tattoo/Piercing (Last 6 months)
                    </label>
                </div>

                {/* Error & Success Messages */}
                {setupError && <p style={styles.errorText}>{setupError}</p>}
                {setupSuccess && <p style={styles.successText}>{setupSuccess}</p>}

                <button type="submit" style={styles.saveButton} disabled={isSaving}>
                    {isSaving ? 'Saving...' : 'Save Profile'}
                </button>
            </form>
        </div>
    );
};

const styles = {
    formContainer: {
        backgroundColor: '#1e1e1e',
        padding: '25px',
        borderRadius: '15px',
        boxShadow: '0 5px 15px rgba(0,0,0,0.3)',
        color: '#fff',
        maxWidth: '600px',
        marginTop: '20px'
    },
    heading: { color: '#e74c3c', marginBottom: '10px' },
    subHeading: { color: '#ccc', fontSize: '0.95rem', marginBottom: '20px' },
    form: { display: 'flex', flexDirection: 'column', gap: '15px' },
    label: { display: 'flex', flexDirection: 'column', fontWeight: '500', fontSize: '0.95rem' },
    input: {
        marginTop: '5px',
        padding: '10px 12px',
        borderRadius: '8px',
        border: '1px solid #444',
        backgroundColor: '#2c2c2c',
        color: '#fff',
        fontSize: '0.95rem',
        outline: 'none'
    },
    checkboxContainer: {
        display: 'flex',
        flexDirection: 'column',
        gap: '10px',
        backgroundColor: '#252525',
        padding: '12px',
        borderRadius: '8px',
        marginTop: '5px'
    },
    checkboxLabel: {
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        fontSize: '0.9rem',
        cursor: 'pointer'
    },
    checkbox: {
        width: '18px',
        height: '18px',
        cursor: 'pointer',
        accentColor: '#e74c3c'
    },
    helperText: { fontSize: '0.8rem', color: '#aaa', marginTop: '3px' },
    errorText: { color: '#ff4d4d', fontWeight: '500', marginTop: '5px' },
    successText: { color: '#2ecc71', fontWeight: '500', marginTop: '5px' },
    saveButton: {
        marginTop: '10px',
        padding: '12px',
        borderRadius: '10px',
        backgroundColor: '#e74c3c',
        color: '#fff',
        border: 'none',
        cursor: 'pointer',
        fontWeight: '600',
        fontSize: '1rem'
    }
};

export default ProfileSetupForm;