// src/components/DonorSearch.jsx

import React, { useState, useEffect } from 'react';
import API from '../services/api';
import { useAuth } from '../context/AuthContext';

const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

const DonorSearch = () => {
    const { user } = useAuth();
    const [donors, setDonors] = useState([]);
    const [searchParams, setSearchParams] = useState({
        city: user?.city || '', 
        bloodGroup: '',
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    const handleSearch = async (e) => {
        if (e) e.preventDefault();
        setLoading(true);
        setError(null);

        const params = new URLSearchParams({
            city: searchParams.city,
            bloodGroup: searchParams.bloodGroup,
        }).toString();

        try {
            // Backend Route: /api/donor/search
            const res = await API.get(`/donor/search?${params}`);
            setDonors(res.data);
        } catch (err) {
            console.error('Donor Search Error:', err);
            setError(err.response?.data?.msg || 'Failed to fetch donors.');
            setDonors([]);
        } finally {
            setLoading(false);
        }
    };

    const handleChange = (e) => {
        setSearchParams({ ...searchParams, [e.target.name]: e.target.value });
    };
    
    useEffect(() => {
        if (user && user.city) {
            handleSearch(null); 
        }
    }, [user]); 

    return (
        <div className="donor-search-container" style={styles.container}>
            <h3 style={styles.heading}>Find Available Donors</h3>

            <form onSubmit={handleSearch} style={styles.form}>
                <input 
                    type="text" 
                    name="city" 
                    value={searchParams.city} 
                    onChange={handleChange} 
                    placeholder="City" 
                    required 
                    style={styles.input} 
                />
                <select 
                    name="bloodGroup" 
                    value={searchParams.bloodGroup} 
                    onChange={handleChange} 
                    style={styles.input}
                >
                    <option value="">All Blood Groups</option>
                    {bloodGroups.map(group => (
                        <option key={group} value={group}>{group}</option>
                    ))}
                </select>
                <button type="submit" disabled={loading} style={styles.button}>
                    {loading ? 'Searching...' : 'Search Donors'}
                </button>
            </form>

            {error && <p style={styles.error}>{error}</p>}

            <div style={styles.results}>
                <h4 style={styles.resultsHeading}>Eligible Donors in {searchParams.city} ({donors.length})</h4>
                {donors.length === 0 && !loading && <p style={styles.noResults}>No eligible donors found matching your criteria.</p>}
                
                {donors.length > 0 && (
                    <table style={styles.table}>
                        <thead>
                            <tr>
                                <th style={styles.th}>Name</th>
                                <th style={styles.th}>Blood Group</th>
                                <th style={styles.th}>Contact</th>
                            </tr>
                        </thead>
                        <tbody>
                            {donors.map((donor, index) => (
                                <tr key={index} style={index % 2 === 0 ? styles.trEven : styles.trOdd}>
                                    <td style={styles.td}>{donor.name}</td>
                                    <td style={styles.td}>{donor.healthProfile.bloodGroup}</td>
                                    <td style={styles.td}>{donor.contactNumber}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
};

// Minimal Styles
const styles = {
    container: {
        backgroundColor: '#3A3A3A', 
        padding: '20px', 
        borderRadius: '10px', 
        maxWidth: '800px', 
        margin: '20px auto', 
        color: 'white'
    },
    heading: {
        borderBottom: '2px solid #DC3545',
        paddingBottom: '10px',
        marginBottom: '20px',
        color: '#FFFFFF'
    },
    form: {
        display: 'flex',
        gap: '10px',
        marginBottom: '20px',
    },
    input: {
        padding: '10px',
        borderRadius: '5px',
        border: '1px solid #444',
        backgroundColor: '#2D2D2D',
        color: 'white',
        flex: 1,
    },
    button: {
        padding: '10px 15px',
        backgroundColor: '#DC3545',
        color: 'white',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer',
    },
    error: { color: '#FF6347', fontWeight: 'bold' },
    results: { marginTop: '30px' },
    resultsHeading: { color: '#CCC', marginBottom: '15px' },
    noResults: { color: '#AAAAAA' },
    table: { width: '100%', borderCollapse: 'collapse' },
    th: { padding: '10px', borderBottom: '1px solid #555', textAlign: 'left', color: '#DC3545' },
    td: { padding: '10px', borderBottom: '1px solid #444' },
    trEven: { backgroundColor: '#333333' },
    trOdd: { backgroundColor: '#3A3A3A' },
};

export default DonorSearch;