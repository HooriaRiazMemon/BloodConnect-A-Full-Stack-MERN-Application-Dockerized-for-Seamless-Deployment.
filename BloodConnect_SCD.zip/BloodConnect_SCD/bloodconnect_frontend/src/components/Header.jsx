// src/components/Header.jsx
import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const Header = () => {
    const { role, logout } = useAuth();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    return (
        <div style={styles.header}>
            <div style={styles.logo}>
                BloodConnect | <span style={styles.roleText}>{role} Portal</span>
            </div>
            <button 
                onClick={handleLogout} 
                style={styles.logoutButton}
            >
                Logout
            </button>
        </div>
    );
};

const styles = {
    header: {
        backgroundColor: '#2D2D2D',
        padding: '15px 30px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        borderBottom: '2px solid #DC3545',
    },
    logo: {
        fontSize: '20px',
        fontWeight: 'bold',
        color: '#FFFFFF',
    },
    roleText: {
        color: '#3498DB',
        fontSize: '16px',
    },
    logoutButton: {
        backgroundColor: '#DC3545',
        color: 'white',
        border: 'none',
        padding: '10px 15px',
        borderRadius: '5px',
        cursor: 'pointer',
        fontWeight: 'bold',
        transition: 'background-color 0.3s',
    }
};

export default Header;