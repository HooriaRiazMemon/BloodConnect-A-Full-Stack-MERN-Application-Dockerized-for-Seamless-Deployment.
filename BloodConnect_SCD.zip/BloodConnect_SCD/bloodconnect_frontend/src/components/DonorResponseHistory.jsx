
import React, { useState, useEffect, useCallback } from 'react';
import API from '../services/api';

const DonorResponseHistory = () => {
    const [respondedRequests, setRespondedRequests] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const fetchResponseHistory = useCallback(async () => {
        setLoading(true);
        try {
            const res = await API.get('/requests/my-responses');
            setRespondedRequests(res.data);
        } catch (err) {
            console.error('Response History Fetch Error:', err);
            setError(err.response?.data?.msg || 'Failed to fetch your response history.');
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchResponseHistory();
    }, [fetchResponseHistory]);

    if (loading) return <p style={styles.loading}>Loading your response history...</p>;
    if (error) return <p style={styles.error}>Error: {error}</p>;

    return (
        <div style={styles.container}>
            <h3 style={styles.heading}>Your Response History</h3>
            
            {respondedRequests.length === 0 && <p style={styles.noResponses}>You have not responded to any blood requests yet.</p>}

            {respondedRequests.map((req) => (
                <div key={req._id} style={{ ...styles.requestCard, ...styles[req.status.toLowerCase()] }}>
                    <div style={styles.cardHeader}>
                        <div style={styles.bloodGroupBox}>{req.bloodGroup}</div>
                        <div>
                            <p style={styles.title}>{req.hospitalName} in {req.city}</p>
                            <p style={styles.subTitle}>Required: {req.requiredUnits} Units | Status: **{req.status}**</p>
                        </div>
                    </div>
                    
                    {/* Donor ka apna response time dhondna */}
                    {req.donorResponses.find(res => res.donorId.toString() === req.user?.id) && (
                        <p style={styles.responseTime}>
                            You responded on: {new Date(req.donorResponses.find(res => res.donorId.toString() === req.user?.id)?.respondedAt).toLocaleDateString()}
                        </p>
                    )}
                    
                    <p style={styles.contact}>Receiver Contact: {req.contactPhone}</p>
                </div>
            ))}
        </div>
    );
};

const styles = {
    container: { maxWidth: '800px', margin: '20px auto' },
    heading: { color: '#FFFFFF', borderBottom: '2px solid #3498DB', paddingBottom: '10px', marginBottom: '20px' },
    loading: { color: 'white', textAlign: 'center' },
    error: { color: '#FF6347', textAlign: 'center' },
    noResponses: { color: '#AAAAAA', textAlign: 'center' },
    requestCard: { 
        padding: '15px', borderRadius: '8px', marginBottom: '15px', 
        borderLeft: '5px solid', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.5)' 
    },
    pending: { backgroundColor: '#3A3A3A', borderLeftColor: '#F0AD4E' },
    fulfilled: { backgroundColor: '#3A3A3A', borderLeftColor: '#28A745' },
    cancelled: { backgroundColor: '#3A3A3A', borderLeftColor: '#DC3545' },
    cardHeader: { display: 'flex', alignItems: 'center', marginBottom: '10px' },
    bloodGroupBox: { 
        backgroundColor: '#DC3545', color: 'white', padding: '10px', 
        borderRadius: '5px', fontWeight: 'bold', fontSize: '1.2em', marginRight: '15px' 
    },
    title: { fontSize: '1.1em', fontWeight: 'bold', margin: '0' },
    subTitle: { fontSize: '0.9em', color: '#CCCCCC', margin: '5px 0' },
    contact: { fontSize: '0.9em', color: '#F8F9FA', marginTop: '10px' },
    responseTime: { fontSize: '0.85em', color: '#3498DB', fontStyle: 'italic' }
};

export default DonorResponseHistory;