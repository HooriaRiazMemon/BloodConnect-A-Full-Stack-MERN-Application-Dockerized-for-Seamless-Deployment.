import React, { createContext, useContext, useState, useEffect } from 'react';
import API from '../services/api'; 

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [loading, setLoading] = useState(true);
    const [token, setToken] = useState(null);
    const [role, setRole] = useState(null);
    const [user, setUser] = useState(null);
    
    // --- UI States ---
    const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
    const [hoverBtn, setHoverBtn] = useState(null); 

    useEffect(() => {
        const storedToken = localStorage.getItem('token');
        const storedRole = localStorage.getItem('role');
        if (storedToken && storedRole) {
            fetchUserData(storedToken, storedRole);
        } else {
            setLoading(false);
        }
    }, []);

    const fetchUserData = async (currentToken, currentRole) => {
        try {
            const endpoint = currentRole === 'Donor' ? '/donor/me' : '/receiver/me';
            const res = await API.get(endpoint);
            const userDataFromBackend = res.data.user;
            setUser({ id: userDataFromBackend._id, name: userDataFromBackend.name, email: userDataFromBackend.email, city: userDataFromBackend.city }); 
            setRole(currentRole); setToken(currentToken); setIsAuthenticated(true);
        } catch (error) { logout(); } finally { setLoading(false); }
    };

    const login = async (userEmail, userPassword) => {
        setLoading(true);
        try {
            const res = await API.post('/auth/login', { email: userEmail, password: userPassword }); 
            const { token, role } = res.data;
            localStorage.setItem('token', token); localStorage.setItem('role', role);
            await fetchUserData(token, role); 
            return { success: true, userRole: role };
        } catch (err) {
            setLoading(false);
            return { success: false, message: err.response?.data?.msg || 'Login failed' };
        }
    };

    const logout = () => {
        localStorage.removeItem('token'); localStorage.removeItem('role');
        setIsAuthenticated(false); setToken(null); setRole(null); setUser(null);
        setLoading(false); setShowLogoutConfirm(false);
    };

    return (
        <AuthContext.Provider value={{ isAuthenticated, loading, token, role, user, login, logout: () => setShowLogoutConfirm(true) }}>
            {children}

            {/* Logout Modal --- */}
            {showLogoutConfirm && (
                <div style={styles.overlay}>
                    <div style={styles.modal}>
                        <div style={styles.icon}>👋</div>
                        <h2 style={styles.title}>Logging Out?</h2>
                        <p style={styles.text}>Are you sure you want to exit BloodConnect?</p>
                        
                        <div style={styles.btnGroup}>
                            <button 
                                onMouseEnter={() => setHoverBtn('cancel')}
                                onMouseLeave={() => setHoverBtn(null)}
                                onClick={() => setShowLogoutConfirm(false)} 
                                style={{
                                    ...styles.cancelBtn,
                                    ...(hoverBtn === 'cancel' ? styles.cancelHover : {})
                                }}
                            >
                                Not Now
                            </button>
                            
                            <button 
                                onMouseEnter={() => setHoverBtn('logout')}
                                onMouseLeave={() => setHoverBtn(null)}
                                onClick={logout} 
                                style={{
                                    ...styles.logoutBtn,
                                    ...(hoverBtn === 'logout' ? styles.logoutHover : {})
                                }}
                            >
                                Yes, Logout
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </AuthContext.Provider>
    );
};

const styles = {
    overlay: {
        position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
        backgroundColor: 'rgba(0,0,0,0.8)', display: 'flex', justifyContent: 'center',
        alignItems: 'center', zIndex: 10000, backdropFilter: 'blur(10px)'
    },
    modal: {
        backgroundColor: '#181818', padding: '40px', borderRadius: '25px',
        textAlign: 'center', maxWidth: '380px', width: '90%',
        border: '1px solid #333', boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
        transform: 'scale(1)', transition: 'all 0.3s ease'
    },
    icon: { fontSize: '45px', marginBottom: '15px' },
    title: { color: 'white', fontSize: '1.6rem', marginBottom: '10px' },
    text: { color: '#aaa', marginBottom: '30px' },
    btnGroup: { display: 'flex', gap: '15px' },
    cancelBtn: {
        flex: 1, padding: '12px', borderRadius: '12px', border: '1px solid #444',
        backgroundColor: '#252525', color: 'white', cursor: 'pointer',
        fontWeight: 'bold', transition: 'all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)'
    },
    cancelHover: {
        transform: 'translateY(-5px)', backgroundColor: '#333', borderColor: '#666'
    },
    logoutBtn: {
        flex: 1, padding: '12px', borderRadius: '12px', border: 'none',
        backgroundColor: '#e74c3c', color: 'white', cursor: 'pointer',
        fontWeight: 'bold', transition: 'all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)',
        boxShadow: '0 4px 15px rgba(231, 76, 60, 0.3)'
    },
    logoutHover: {
        transform: 'translateY(-5px)', backgroundColor: '#c0392b',
        boxShadow: '0 8px 25px rgba(231, 76, 60, 0.5)'
    }
};