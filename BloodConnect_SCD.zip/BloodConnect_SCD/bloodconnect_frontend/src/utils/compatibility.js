// src/utils/compatibility.js

const compatibilityMap = {
    'O-': ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'], // Universal Donor
    'O+': ['A+', 'B+', 'AB+', 'O+'],
    'A-': ['A+', 'A-', 'AB+', 'AB-'],
    'A+': ['A+', 'AB+'],
    'B-': ['B+', 'B-', 'AB+', 'AB-'],
    'B+': ['B+', 'AB+'],
    'AB-': ['AB+', 'AB-'],
    'AB+': ['AB+'], // Universal Recipient
};


export const getRecipientGroups = (donorGroup) => {
    // Standardize input
    const normalizedGroup = donorGroup.toUpperCase();
    
    return compatibilityMap[normalizedGroup] || [];
};

export const getDonorGroups = (patientGroup) => {
    const compatibleDonors = [];
    const normalizedPatientGroup = patientGroup.toUpperCase();
    
    for (const donor in compatibilityMap) {
        if (compatibilityMap[donor].includes(normalizedPatientGroup)) {
            compatibleDonors.push(donor);
        }
    }
    return compatibleDonors;
};