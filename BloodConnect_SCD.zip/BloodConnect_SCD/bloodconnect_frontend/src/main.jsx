// src/main.jsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx'; // Note: Vite mein extension .jsx ya .js lagana zaroori hai
// Import karein
import { AuthProvider } from './context/AuthContext'; 

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    {/* Wrap karna */}
    <AuthProvider> 
      <App />
    </AuthProvider>
  </React.StrictMode>,
);