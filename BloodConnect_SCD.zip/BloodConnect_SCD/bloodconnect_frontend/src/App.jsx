import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';

import Login from './pages/Login.jsx'; 
import Register from './pages/Register.jsx';
import DonorDashboard from './pages/DonorDashboard.jsx';
import ReceiverDashboard from './pages/ReceiverDashboard.jsx';

const PrivateRoute = ({ children, allowedRoles }) => {
    const { isAuthenticated, loading, role } = useAuth();
    
    if (loading) {
        return <div>Loading...</div>; 
    }
    if (!isAuthenticated) {
        return <Navigate to="/login" replace />;
    }
    const normalizedRole = role ? role.toLowerCase() : '';
    if (allowedRoles && !allowedRoles.map(r => r.toLowerCase()).includes(normalizedRole)) {
        return <h1>Access Denied: You are logged in as {role}</h1>;
    }
    return children;
};

function App() {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {}
        <Route 
            path="/donor-dashboard" 
            element={
                <PrivateRoute allowedRoles={['Donor']}>
                    <DonorDashboard />
                </PrivateRoute>
            } 
        />
        
        {}
        <Route 
            path="/receiver-dashboard" 
            element={
                <PrivateRoute allowedRoles={['Receiver']}>
                    <ReceiverDashboard />
                </PrivateRoute>
            } 
        />
        
        {/* 404 Route */}
        <Route path="*" element={<h1>404: Page Not Found</h1>} />
      </Routes>
    </Router>
  );
}

export default App;