import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import API from '../services/api';

const ReceiverDashboard = () => {
    const { user, logout } = useAuth();
    const [requests, setRequests] = useState([]);
    const [formData, setFormData] = useState({
        bloodGroup: 'A+',
        requiredUnits: 1,
        hospitalName: '',
        urgency: 'Normal'
    });
    const [selectedDonors, setSelectedDonors] = useState(null);
    const [loading, setLoading] = useState(false);
    const [msg, setMsg] = useState('');

    // --- CONFIRM MODAL STATE ---
    const [confirmModal, setConfirmModal] = useState({ visible: false, message: '', onConfirm: null });

    // --- FETCH DATA ---
    const fetchMyRequests = async () => {
        try {
            const res = await API.get('/requests/my');
            setRequests(res.data);
        } catch (err) {
            console.error('Error fetching requests:', err);
        }
    };

    useEffect(() => {
        fetchMyRequests();
        const interval = setInterval(fetchMyRequests, 30000);
        return () => clearInterval(interval);
    }, []);

    // --- HANDLERS ---
    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await API.post('/requests', formData);
            setMsg('✅ Blood request posted successfully!');
            setFormData({ bloodGroup: 'A+', requiredUnits: 1, hospitalName: '', urgency: 'Normal' });
            fetchMyRequests(); 
        } catch (err) {
            setMsg('❌ ' + (err.response?.data?.msg || 'Failed to create request'));
        } finally {
            setLoading(false);
            setTimeout(() => setMsg(''), 4000);
        }
    };

    const handleStatusUpdate = (id, status) => {
        setConfirmModal({
            visible: true,
            message: "Is this request fulfilled? This will hide it from donors.",
            onConfirm: async () => {
                try {
                    await API.put(`/requests/${id}/status`, { status });
                    fetchMyRequests();
                } catch (err) {
                    alert("Error updating status");
                } finally {
                    setConfirmModal({ visible: false, message: '', onConfirm: null });
                }
            }
        });
    };

    const handleDelete = (id) => {
        setConfirmModal({
            visible: true,
            message: "Delete this request permanently?",
            onConfirm: async () => {
                try {
                    await API.delete(`/requests/${id}`);
                    fetchMyRequests();
                } catch (err) {
                    alert("Error deleting request");
                } finally {
                    setConfirmModal({ visible: false, message: '', onConfirm: null });
                }
            }
        });
    };

    const handleViewDonors = (donorResponses) => {
        if (!donorResponses || donorResponses.length === 0) {
            alert("No donors have responded yet. We'll notify you when someone does!");
            return;
        }
        setSelectedDonors(donorResponses);
    };

    return (
        <div style={styles.container}>
            {/* Header Section */}
            <div style={styles.header}>
                <div>
                    <h2 style={{margin: 0, color: '#e74c3c'}}>🩸 BloodConnect</h2>
                    <p style={{margin: 0, fontSize: '12px', color: '#888'}}>Receiver Control Panel</p>
                </div>
                <div style={{display: 'flex', alignItems: 'center', gap: '15px'}}>
                    <div style={styles.userBadge}>{user?.name}</div>
                    <button onClick={logout} style={styles.logoutBtn}>Logout</button>
                </div>
            </div>

            {/* Dashboard Stats */}
            <div style={styles.infoBox}>
                <h4 style={{margin: '0 0 10px 0'}}>Welcome back, {user?.name}!</h4>
                <div style={{display: 'flex', gap: '20px', fontSize: '14px'}}>
                    <span>📍 <strong>City:</strong> {user?.city}</span>
                    <span>📊 <strong>Active Requests:</strong> {requests.filter(r => r.status === 'Pending').length}</span>
                </div>
            </div>

            {/* Request Form */}
            <div style={styles.section}>
                <h3 style={styles.sectionTitle}>Request Blood Units</h3>
                <form onSubmit={handleSubmit} style={styles.form}>
                    <div style={styles.inputGroup}>
                        <label style={styles.label}>Blood Group</label>
                        <select name="bloodGroup" value={formData.bloodGroup} onChange={handleChange} style={styles.input}>
                            {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(bg => (
                                <option key={bg} value={bg}>{bg}</option>
                            ))}
                        </select>
                    </div>
                    <div style={styles.inputGroup}>
                        <label style={styles.label}>Units</label>
                        <input type="number" name="requiredUnits" min="1" value={formData.requiredUnits} onChange={handleChange} required style={styles.input} />
                    </div>
                    <div style={{...styles.inputGroup, flex: 2}}>
                        <label style={styles.label}>Hospital & Location</label>
                        <input type="text" name="hospitalName" placeholder="e.g. City Hospital, Wing B" value={formData.hospitalName} onChange={handleChange} required style={styles.input} />
                    </div>
                    <div style={styles.inputGroup}>
                        <label style={styles.label}>Urgency</label>
                        <select name="urgency" value={formData.urgency} onChange={handleChange} style={styles.input}>
                            <option value="Normal">Normal</option>
                            <option value="Urgent">Urgent</option>
                            <option value="Critical">Critical (ASAP)</option>
                        </select>
                    </div>
                    <button type="submit" disabled={loading} style={styles.submitBtn}>
                        {loading ? 'Processing...' : 'Post Request'}
                    </button>
                </form>
                {msg && <p style={{marginTop: '15px', padding: '10px', borderRadius: '5px', backgroundColor: msg.includes('✅') ? 'rgba(40,167,69,0.1)' : 'rgba(231,76,60,0.1)', color: msg.includes('✅') ? '#28A745' : '#e74c3c'}}>{msg}</p>}
            </div>

            {/* Requests Table */}
            <div style={styles.section}>
                <h3 style={styles.sectionTitle}>My Requests Tracker</h3>
                <div style={styles.tableWrapper}>
                    <table style={styles.table}>
                        <thead>
                            <tr style={styles.thRow}>
                                <th style={styles.th}>Blood Group</th>
                                <th style={styles.th}>Hospital</th>
                                <th style={styles.th}>Urgency</th>
                                <th style={styles.th}>Status</th>
                                <th style={styles.th}>Donor Help</th>
                                <th style={styles.th}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {requests.length > 0 ? requests.map(req => (
                                <tr key={req._id} style={styles.tr}>
                                    <td style={styles.td}><span style={styles.bloodBadge}>{req.bloodGroup}</span></td>
                                    <td style={styles.td}>{req.hospitalName}</td>
                                    <td style={styles.td}>
                                        <span style={{color: req.urgency === 'Critical' ? '#ff4d4d' : req.urgency === 'Urgent' ? '#ffa500' : '#bbb'}}>
                                            {req.urgency}
                                        </span>
                                    </td>
                                    <td style={{...styles.td, color: req.status === 'Pending' ? '#FFA500' : '#4CAF50'}}>{req.status}</td>
                                    <td style={styles.td}>
                                        <button onClick={() => handleViewDonors(req.donorResponses)} style={styles.viewBtn}>
                                            View ({req.donorResponses?.length || 0})
                                        </button>
                                    </td>
                                    <td style={styles.td}>
                                        <div style={{display: 'flex', gap: '8px'}}>
                                            {req.status === 'Pending' && (
                                                <button onClick={() => handleStatusUpdate(req._id, 'Fulfilled')} style={styles.doneBtn} title="Mark as Fulfilled">Done</button>
                                            )}
                                            <button onClick={() => handleDelete(req._id)} style={styles.delBtn} title="Delete Request">🗑</button>
                                        </div>
                                    </td>
                                </tr>
                            )) : (
                                <tr><td colSpan="6" style={{padding: '30px', textAlign: 'center', color: '#666'}}>No requests found. Create one above!</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Donor List Modal */}
            {selectedDonors && (
                <div style={styles.modalOverlay} onClick={() => setSelectedDonors(null)}>
                    <div style={styles.modalContent} onClick={e => e.stopPropagation()}>
                        <div style={styles.modalHeader}>
                            <h4 style={{margin: 0}}>Potential Donors ({selectedDonors.length})</h4>
                            <button onClick={() => setSelectedDonors(null)} style={styles.closeBtn}>×</button>
                        </div>
                        <div style={styles.donorList}>
                            {selectedDonors.map((donor, idx) => (
                                <div key={idx} style={styles.donorCard}>
                                    <div style={{flex: 1}}>
                                        <p style={{margin: '0 0 5px 0', fontSize: '16px'}}><strong>{donor.donorName}</strong></p>
                                        <p style={{margin: 0, color: '#aaa', fontSize: '13px'}}>Contact: {donor.contactNumber}</p>
                                    </div>
                                    <a href={`tel:${donor.contactNumber}`} style={styles.callBtn}>📞 Call</a>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* --- CONFIRMATION MODAL --- */}
            {confirmModal.visible && (
                <div style={styles.modalOverlay} onClick={() => setConfirmModal({ visible: false, message: '', onConfirm: null })}>
                    <div style={styles.modalContent} onClick={e => e.stopPropagation()}>
                        <p style={{marginBottom: '20px'}}>{confirmModal.message}</p>
                        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                            <button onClick={() => setConfirmModal({ visible: false, message: '', onConfirm: null })} style={styles.delBtn}>Cancel</button>
                            <button onClick={confirmModal.onConfirm} style={styles.doneBtn}>Confirm</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

// --- STYLES OBJECT (same as before) ---
const styles = {
    container: { padding: '30px', backgroundColor: '#0f0f0f', color: '#efefef', minHeight: '100vh', fontFamily: "'Inter', sans-serif" },
    header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' },
    userBadge: { backgroundColor: '#1e1e1e', padding: '8px 15px', borderRadius: '20px', fontSize: '14px', border: '1px solid #333' },
    logoutBtn: { backgroundColor: 'transparent', color: '#ff4d4d', border: '1px solid #ff4d4d', padding: '8px 15px', borderRadius: '8px', cursor: 'pointer', fontWeight: '500', transition: '0.3s' },
    infoBox: { backgroundColor: '#161616', padding: '20px', borderRadius: '12px', marginBottom: '30px', border: '1px solid #222' },
    section: { marginBottom: '50px' },
    sectionTitle: { fontSize: '18px', fontWeight: '600', marginBottom: '20px', color: '#fff', borderLeft: '4px solid #e74c3c', paddingLeft: '12px' },
    form: { display: 'flex', gap: '15px', flexWrap: 'wrap', alignItems: 'flex-end', backgroundColor: '#161616', padding: '20px', borderRadius: '12px', border: '1px solid #222' },
    inputGroup: { display: 'flex', flexDirection: 'column', gap: '8px' },
    label: { fontSize: '12px', color: '#888', fontWeight: '500' },
    input: { padding: '12px', borderRadius: '8px', border: '1px solid #333', backgroundColor: '#0a0a0a', color: 'white', fontSize: '14px', outline: 'none' },
    submitBtn: { backgroundColor: '#e74c3c', color: 'white', border: 'none', padding: '12px 25px', borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', height: '45px' },
    tableWrapper: { backgroundColor: '#161616', borderRadius: '12px', overflow: 'hidden', border: '1px solid #222' },
    table: { width: '100%', borderCollapse: 'collapse', textAlign: 'left' },
    thRow: { backgroundColor: '#1e1e1e' },
    th: { padding: '15px', color: '#777', textTransform: 'uppercase', fontSize: '11px', letterSpacing: '1px' },
    tr: { borderBottom: '1px solid #222', transition: '0.2s' },
    td: { padding: '15px', fontSize: '14px' },
    bloodBadge: { backgroundColor: 'rgba(231,76,60,0.2)', color: '#e74c3c', padding: '4px 10px', borderRadius: '6px', fontWeight: 'bold' },
    viewBtn: { backgroundColor: '#3498db', color: 'white', border: 'none', padding: '6px 14px', borderRadius: '6px', cursor: 'pointer', fontSize: '12px' },
    doneBtn: { backgroundColor: '#2ecc71', color: 'white', border: 'none', padding: '6px 12px', borderRadius: '6px', cursor: 'pointer', fontSize: '12px' },
    delBtn: { backgroundColor: 'transparent', color: '#ff4d4d', border: '1px solid #ff4d4d', padding: '6px 10px', borderRadius: '6px', cursor: 'pointer' },
    modalOverlay: { position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', backgroundColor: 'rgba(0,0,0,0.9)', display: 'flex', justifyContent: 'center', alignItems: 'center', zIndex: 1000 },
    modalContent: { backgroundColor: '#161616', padding: '25px', borderRadius: '15px', width: '90%', maxWidth: '400px', border: '1px solid #333' },
    modalHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' },
    closeBtn: { background: 'none', border: 'none', color: '#666', fontSize: '28px', cursor: 'pointer' },
    donorCard: { backgroundColor: '#1e1e1e', padding: '15px', borderRadius: '10px', marginBottom: '12px', display: 'flex', alignItems: 'center', border: '1px solid #333' },
    callBtn: { backgroundColor: '#2ecc71', color: 'white', textDecoration: 'none', padding: '8px 15px', borderRadius: '8px', fontSize: '13px', fontWeight: 'bold' }
};

export default ReceiverDashboard;
