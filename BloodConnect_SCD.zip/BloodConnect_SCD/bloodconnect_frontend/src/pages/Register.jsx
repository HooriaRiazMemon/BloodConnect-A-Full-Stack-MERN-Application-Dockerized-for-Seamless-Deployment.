
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../services/api';
import { useAuth } from '../context/AuthContext';


const Register = () => {
    const navigate = useNavigate();
    const { login } = useAuth();


    const [role, setRole] = useState(null);
    const [hovered, setHovered] = useState(null); 
    const [formData, setFormData] = useState({
        name: '', email: '', password: '', phone: '', location: '', bloodGroup: '',
    });
   
    const [error, setError] = useState(null);
    const [successMsg, setSuccessMsg] = useState(null);
    const [isSubmitting, setIsSubmitting] = useState(false);


    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
        if (error) setError(null);
    };


    const handleRoleSelect = (selectedRole) => {
        setRole(selectedRole);
        setFormData({ name: '', email: '', password: '', phone: '', location: '', bloodGroup: '' });
        setError(null);
    };


    const createPayload = (role, formData) => {
        const basePayload = {
            name: formData.name,
            email: formData.email,
            password: formData.password,
            role: role,
            city: formData.location,
            contactNumber: formData.phone,
        };
        if (role === 'Donor') {
            basePayload.healthProfile = { bloodGroup: formData.bloodGroup };
        }
        return basePayload;
    };


    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        setError(null);
       
        if (role === 'Donor' && !formData.bloodGroup) {
            setError('Please select your blood group.');
            setIsSubmitting(false);
            return;
        }


        const payload = createPayload(role, formData);


        try {
            const res = await API.post('/auth/register', payload);
            const { token, user } = res.data;
            login(token, user);
            setSuccessMsg(`Account created! Redirecting to ${role} Dashboard...`);
            setTimeout(() => {
                navigate(user.role === 'Donor' ? '/donor-dashboard' : '/receiver-dashboard');
            }, 2500);
        } catch (err) {
            setError(err.response?.data?.msg || 'Registration failed.');
        } finally {
            setIsSubmitting(false);
        }
    };


    // Stage 1: Role Selection UI
    const renderRoleSelection = () => (
        <div style={styles.glassBox}>
            <h2 style={styles.heading}>Join BloodConnect</h2>
            <div style={styles.redDivider}></div>
            <p style={styles.text}>Are you registering as a Donor or a Receiver?</p>
           
            <div style={styles.roleButtonsContainer}>
                <button
                    onMouseEnter={() => setHovered('Donor')}
                    onMouseLeave={() => setHovered(null)}
                    style={{
                        ...styles.roleButton, ...styles.donorBtn,
                        ...(hovered === 'Donor' ? styles.btnHoverEffect : {})
                    }}
                    onClick={() => handleRoleSelect('Donor')}
                >
                    <span style={{fontSize: '24px'}}>🩸</span><br/>Donor
                </button>
                <button
                    onMouseEnter={() => setHovered('Receiver')}
                    onMouseLeave={() => setHovered(null)}
                    style={{
                        ...styles.roleButton, ...styles.receiverBtn,
                        ...(hovered === 'Receiver' ? styles.btnHoverEffect : {})
                    }}
                    onClick={() => handleRoleSelect('Receiver')}
                >
                    <span style={{fontSize: '24px'}}>🏥</span><br/>Receiver
                </button>
            </div>
            <p style={styles.linkText}>
                Already have an account? <span onClick={() => navigate('/login')} style={styles.link}>Login Here</span>
            </p>
        </div>
    );


    // Stage 2: Main Registration Form UI
    const renderRegistrationForm = () => (
        <div style={styles.glassBox}>
            <h3 style={styles.formHeading}>Creating {role} Profile</h3>
            <form onSubmit={handleSubmit} style={styles.form}>
                <input type="text" name="name" placeholder="Full Name" value={formData.name} onChange={handleChange} required style={styles.input} />
                <input type="email" name="email" placeholder="Email Address" value={formData.email} onChange={handleChange} required style={styles.input} />
                <input type="password" name="password" placeholder="Password" value={formData.password} onChange={handleChange} required style={styles.input} />
                <input type="text" name="phone" placeholder="Phone Number" value={formData.phone} onChange={handleChange} required style={styles.input} />
                <input type="text" name="location" placeholder="Your City (e.g., Karachi)" value={formData.location} onChange={handleChange} required style={styles.input} />


                {role === 'Donor' && (
                    <select name="bloodGroup" value={formData.bloodGroup} onChange={handleChange} required style={styles.input}>
                        <option value="">Select Blood Group</option>
                        {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(bg => (
                            <option key={bg} value={bg}>{bg}</option>
                        ))}
                    </select>
                )}


                {error && <p style={styles.error}>{error}</p>}
                {successMsg && <p style={styles.success}>{successMsg}</p>}


                <button
                    type="submit"
                    onMouseEnter={() => setHovered('submit')}
                    onMouseLeave={() => setHovered(null)}
                    style={{
                        ...styles.submitBtn,
                        ...(hovered === 'submit' ? styles.btnHoverEffect : {})
                    }}
                    disabled={isSubmitting}
                >
                    {isSubmitting ? 'Processing...' : `Sign Up Now`}
                </button>
            </form>
            <p onClick={() => setRole(null)} style={styles.backLink}>← Change Role</p>
        </div>
    );


    return (
        <div style={styles.container}>
            {!role ? renderRoleSelection() : renderRegistrationForm()}
        </div>
    );
};


// --- ✨ Modern Glassmorphism & Interactive Styles ---
const styles = {
    container: {
        display: 'flex', justifyContent: 'center', alignItems: 'center',
        minHeight: '100vh', backgroundColor: '#0f0f0f', fontFamily: "'Poppins', sans-serif"
    },
    glassBox: {
        backgroundColor: '#1a1a1a', padding: '50px 40px', borderRadius: '25px',
        boxShadow: '0 20px 40px rgba(0,0,0,0.6)', border: '1px solid #333',
        width: '90%', maxWidth: '450px', textAlign: 'center', transition: 'all 0.4s ease'
    },
    heading: { color: '#fff', fontSize: '2rem', marginBottom: '10px', fontWeight: 'bold' },
    redDivider: { width: '50px', height: '4px', backgroundColor: '#e74c3c', margin: '0 auto 20px auto', borderRadius: '2px' },
    text: { color: '#aaa', marginBottom: '30px', fontSize: '1rem' },
    roleButtonsContainer: { display: 'flex', gap: '20px', marginBottom: '30px' },
    roleButton: {
        flex: 1, padding: '25px 15px', borderRadius: '18px', border: 'none',
        fontSize: '1rem', fontWeight: 'bold', color: '#fff', cursor: 'pointer',
        transition: 'all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)'
    },
    donorBtn: { background: 'linear-gradient(135deg, #e74c3c 0%, #c0392b 100%)', boxShadow: '0 8px 15px rgba(231, 76, 60, 0.2)' },
    receiverBtn: { background: 'linear-gradient(135deg, #27ae60 0%, #2ecc71 100%)', boxShadow: '0 8px 15px rgba(39, 174, 96, 0.2)' },
    btnHoverEffect: { transform: 'translateY(-8px) scale(1.03)', boxShadow: '0 15px 30px rgba(0,0,0,0.4)' },
    form: { display: 'flex', flexDirection: 'column', gap: '15px' },
    input: {
        padding: '14px', borderRadius: '12px', border: '1px solid #333',
        backgroundColor: '#252525', color: '#fff', fontSize: '15px', outline: 'none'
    },
    submitBtn: {
        padding: '15px', borderRadius: '12px', border: 'none', backgroundColor: '#e74c3c',
        color: 'white', fontWeight: 'bold', fontSize: '1rem', cursor: 'pointer',
        marginTop: '10px', transition: 'all 0.3s ease'
    },
    error: { color: '#ff6b6b', fontWeight: '600', fontSize: '14px' },
    success: { color: '#2ecc71', fontWeight: '600', fontSize: '14px' },
    linkText: { marginTop: '20px', color: '#777', fontSize: '0.9rem' },
    link: { color: '#3498db', cursor: 'pointer', fontWeight: 'bold' },
    backLink: { color: '#aaa', marginTop: '20px', cursor: 'pointer', fontSize: '0.85rem' }
};


export default Register;



