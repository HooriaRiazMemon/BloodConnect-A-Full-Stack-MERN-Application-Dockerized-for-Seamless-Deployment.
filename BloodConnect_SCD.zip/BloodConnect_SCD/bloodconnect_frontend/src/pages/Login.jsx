import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Login = () => {
    const [formData, setFormData] = useState({
        email: '',
        password: ''
    });
    const [error, setError] = useState(null);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const { login } = useAuth();
    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
        if (error) setError(null); 
    };

    const handleSubmit = async (e) => {
        e.preventDefault(); 
        
        console.log('Login form submitted. Data:', formData); 

        setIsSubmitting(true);
        setError(null);
        
        
        const result = await login(formData.email, formData.password); 
        setIsSubmitting(false);

        if (result.success) {
            const userRole = result.userRole; 
            
            const normalizedRole = userRole ? userRole.toLowerCase() : '';
            
            let targetPath = '/'; // Default fallback
            
            if (normalizedRole === 'donor') {
                targetPath = '/donor-dashboard';
            } else if (normalizedRole === 'receiver') {
                targetPath = '/receiver-dashboard';
            }

            if (targetPath !== '/') {
                navigate(targetPath, { replace: true });
            }


        } else {
            setError(result.message || 'Login failed. Please check your credentials.');
        }
    };

    return (
        <div style={styles.container}>
            <div style={styles.formBox}>
                <h2 style={styles.heading}>BloodConnect Login</h2>
                <p style={styles.text}>Login to access your life-saving platform</p>

                <form onSubmit={handleSubmit} style={styles.form}>
                    {/* Email Input */}
                    <input
                        type="email"
                        name="email"
                        placeholder="Email Address"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        style={styles.input}
                    />

                    {/* Password Input */}
                    <input
                        type="password"
                        name="password"
                        placeholder="Password"
                        value={formData.password}
                        onChange={handleChange}
                        required
                        style={styles.input}
                    />

                    {/* Error Message */}
                    {error && <p style={styles.error}>{error}</p>}

                    {/* Submit Button */}
                    <button type="submit" style={styles.button} disabled={isSubmitting}>
                        {isSubmitting ? 'Logging in...' : 'Login'}
                    </button>
                </form>

                <p style={styles.linkText}>
                    Don't have an account? <a href="/register" style={styles.link}>Register Here</a>
                </p>
            </div>
        </div>
    );
};

const styles = {
    container: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        backgroundColor: '#1E1E1E', 
    },
    formBox: {
        backgroundColor: '#2D2D2D',
        padding: '40px',
        borderRadius: '10px',
        boxShadow: '0 8px 16px rgba(0, 0, 0, 0.5)',
        width: '380px',
        textAlign: 'center',
    },
    heading: {
        color: '#FFFFFF',
        borderBottom: '2px solid #DC3545',
        paddingBottom: '10px',
        marginBottom: '15px',
    },
    text: {
        color: '#CCCCCC',
        marginBottom: '25px',
    },
    form: {
        display: 'flex',
        flexDirection: 'column',
        gap: '15px',
    },
    input: {
        padding: '12px',
        borderRadius: '6px',
        border: '1px solid #444444',
        backgroundColor: '#3A3A3A',
        color: '#FFFFFF',
        fontSize: '16px',
    },
    button: {
        padding: '12px',
        backgroundColor: '#DC3545',
        color: 'white',
        border: 'none',
        borderRadius: '6px',
        fontSize: '16px',
        fontWeight: 'bold',
        cursor: 'pointer',
        transition: 'background-color 0.3s',
        marginTop: '5px',
    },
    error: {
        color: '#FF6347',
        marginTop: '0px',
        marginBottom: '0px',
        fontWeight: 'bold',
    },
    linkText: {
        marginTop: '25px',
        fontSize: '14px',
        color: '#CCCCCC',
    },
    link: {
        color: '#3498DB',
        textDecoration: 'none',
        fontWeight: 'bold',
    },
};

export default Login;