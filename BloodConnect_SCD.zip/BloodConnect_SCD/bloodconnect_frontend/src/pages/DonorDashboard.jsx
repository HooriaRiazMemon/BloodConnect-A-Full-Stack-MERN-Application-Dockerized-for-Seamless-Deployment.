import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import API from '../services/api';
import ProfileSetupForm from '../components/ProfileSetupForm';
import DonorRequests from '../components/DonorRequests';
import { getRecipientGroups } from '../utils/compatibility';

const DonorDashboard = () => {
    const { user, loading, logout } = useAuth();
    const [donorData, setDonorData] = useState(null);
    const [profileLoading, setProfileLoading] = useState(true);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [hoverBtn, setHoverBtn] = useState(null);

    const fetchDonorData = async () => {
        setProfileLoading(true);
        try {
            const res = await API.get('/donor/me');
            setDonorData(res.data);
        } catch (err) {
            console.error("Donor Data Fetch Error:", err);
            setDonorData(null);
        } finally {
            setProfileLoading(false);
        }
    };

    useEffect(() => {
        if (!loading && user) {
            fetchDonorData();
        }
    }, [loading, user]);

    if (loading || profileLoading) {
        return <div style={styles.loading}>Loading Donor Dashboard...</div>;
    }

    if (!user || (!user.id && !user._id)) {
        return (
            <div style={styles.error}>
                Authentication Error: User session expired.
                <br /><br />
                <button onClick={logout} style={styles.logoutButton}>
                    Login Again
                </button>
            </div>
        );
    }

    const healthProfile = donorData?.user?.healthProfile;
    const isProfileComplete = healthProfile && healthProfile.bloodGroup && healthProfile.weight;
    const eligibility = donorData?.eligibility;
    const isEligible = eligibility?.isEligible;
    const eligibilityReason = eligibility?.reason || 'Please complete your profile.';
    const donorGroup = healthProfile?.bloodGroup || 'Not Set';
    const canDonateTo = getRecipientGroups(donorGroup);

    return (
        <div style={styles.pageWrapper}>
            <div style={styles.container}>

                {/* ---------- HEADER ---------- */}
                <header style={styles.header}>
                    <div style={styles.headerLeft}>
                        <div style={styles.avatar}>{user.name.charAt(0)}</div>
                        <div>
                            <h2 style={{ margin: 0 }}>{`Hello, ${user.name}`}</h2>
                            <p style={styles.userMeta}>{`${user.city} • Donor`}</p>
                        </div>
                    </div>

                    <div style={{ display: 'flex', gap: '12px' }}>
                        <button
                            onMouseEnter={() => setHoverBtn('edit')}
                            onMouseLeave={() => setHoverBtn(null)}
                            onClick={() => setIsEditModalOpen(true)}
                            style={{
                                ...styles.editBtn,
                                ...(hoverBtn === 'edit' ? styles.btnHover : {})
                            }}
                        >
                            ✏️ Edit Profile
                        </button>

                        <button onClick={logout} style={styles.logoutButton}>
                            Logout
                        </button>
                    </div>
                </header>

                {/* ---------- ELIGIBILITY BANNER ---------- */}
                <div
                    style={{
                        ...styles.eligibilityBox,
                        background: !isProfileComplete
                            ? '#2a2a2a'
                            : isEligible
                            ? 'linear-gradient(135deg, #1e7e34 0%, #28a745 100%)'
                            : 'linear-gradient(135deg, #bd2130 0%, #dc3545 100%)',
                        color: '#fff'
                    }}
                >
                    <div style={styles.eligibilityInner}>
                        <p style={styles.eligibilityStatus}>
                            {!isProfileComplete
                                ? 'PROFILE INCOMPLETE'
                                : isEligible
                                ? 'YOU ARE ELIGIBLE TO DONATE'
                                : 'CURRENTLY INELIGIBLE'}
                        </p>
                        <p style={styles.eligibilityReason}>{eligibilityReason}</p>
                    </div>
                </div>

                {/* ---------- PROFILE SETUP ---------- */}
                {!isProfileComplete ? (
                    <div style={styles.sectionCard}>
                        <h3 style={{ color: '#ff6b6b', marginTop: 0 }}>Complete Your Health Profile</h3>
                        <ProfileSetupForm
                            onProfileUpdated={fetchDonorData}
                            userId={user.id || user._id}
                        />
                    </div>
                ) : (
                    <>
                        {/* ---------- IMPACT CARD ---------- */}
                        <div style={styles.impactCard}>
                            <div style={styles.bloodDrop}>🩸</div>
                            <div>
                                <h4 style={styles.impactTitle}>Your Donation Impact</h4>
                                <p style={styles.impactText}>
                                    As a <strong>{donorGroup}</strong> donor, you can help:
                                </p>
                                <div style={styles.badgeList}>
                                    {canDonateTo.map(group => (
                                        <span key={group} style={styles.bloodBadge}>{group}</span>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* ---------- PROFILE SUMMARY ---------- */}
                        <div style={styles.profileSummary}>
                            <h3 style={styles.sectionTitle}>Profile Summary</h3>
                            <div style={styles.summaryGrid}>
                                <div style={styles.summaryItem}>
                                    <strong>Blood Group:</strong> {healthProfile.bloodGroup}
                                </div>
                                <div style={styles.summaryItem}>
                                    <strong>Weight:</strong> {healthProfile.weight} kg
                                </div>
                                <div style={styles.summaryItem}>
                                    <strong>Last Donated:</strong>{' '}
                                    {healthProfile.lastDonationDate
                                        ? new Date(healthProfile.lastDonationDate).toDateString()
                                        : 'Never'}
                                </div>
                            </div>
                        </div>

                        {/* ---------- MATCHING BLOOD REQUESTS ---------- */}
                        <h3 style={styles.sectionHeader}>
                            Matching Blood Requests in {user.city}
                        </h3>
                        <DonorRequests
                            isEligible={isEligible}
                            donorBloodGroup={healthProfile.bloodGroup}
                        />
                    </>
                )}
            </div>
        </div>
    );
};

/* ---------------- STYLES ---------------- */
const styles = {
    pageWrapper: {
        minHeight: '100vh',
        width: '100%',
        backgroundColor: '#121212',
        display: 'flex',
        justifyContent: 'center',
        padding: '40px 0',
        fontFamily: "'Poppins', sans-serif"
    },

    container: {
        maxWidth: '1000px',
        width: '100%',
        padding: '30px 25px',
        backgroundColor: '#1c1c1c',
        color: '#f1f1f1',
        borderRadius: '20px',
        boxShadow: '0 10px 30px rgba(0,0,0,0.5)',
    },

    loading: {
        textAlign: 'center',
        marginTop: '100px',
        color: '#ff4d4d',
        fontSize: '1.3rem',
        fontWeight: '500'
    },

    error: {
        backgroundColor: '#2c0e0e',
        color: '#ff6b6b',
        padding: '30px',
        borderRadius: '15px',
        textAlign: 'center',
        margin: '50px auto',
        maxWidth: '500px'
    },

    header: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '30px',
        borderBottom: '1px solid #333',
        paddingBottom: '20px'
    },

    headerLeft: {
        display: 'flex',
        alignItems: 'center',
        gap: '15px'
    },

    avatar: {
        width: '60px',
        height: '60px',
        backgroundColor: '#e74c3c',
        borderRadius: '50%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: '24px',
        fontWeight: '700',
        boxShadow: '0 4px 12px rgba(0,0,0,0.3)'
    },

    userMeta: {
        margin: 0,
        color: '#bbb',
        fontSize: '0.9rem'
    },

    editBtn: {
        backgroundColor: '#292929',
        color: '#fff',
        border: 'none',
        padding: '10px 22px',
        borderRadius: '12px',
        cursor: 'pointer',
        transition: 'all 0.2s ease'
    },

    btnHover: {
        transform: 'translateY(-3px)',
        boxShadow: '0 6px 12px rgba(0,0,0,0.4)',
        backgroundColor: '#3a3a3a'
    },

    logoutButton: {
        backgroundColor: 'transparent',
        color: '#ff4d4d',
        border: '1px solid #ff4d4d',
        padding: '10px 22px',
        borderRadius: '12px',
        cursor: 'pointer',
        transition: 'all 0.2s ease'
    },

    eligibilityBox: {
        padding: '30px 25px',
        borderRadius: '22px',
        textAlign: 'center',
        marginBottom: '35px',
        border: '1px solid rgba(255,255,255,0.1)',
        boxShadow: '0 10px 25px rgba(0,0,0,0.4)',
        transition: 'all 0.3s ease'
    },

    eligibilityInner: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '8px'
    },

    eligibilityStatus: {
        margin: 0,
        fontSize: '1.5rem',
        fontWeight: '800',
        letterSpacing: '1px'
    },

    eligibilityReason: {
        margin: 0,
        opacity: 0.85,
        fontSize: '1rem',
        maxWidth: '550px'
    },

    impactCard: {
        background: '#232323',
        borderRadius: '20px',
        padding: '25px',
        display: 'flex',
        gap: '20px',
        marginBottom: '25px',
        alignItems: 'center',
        boxShadow: '0 8px 20px rgba(0,0,0,0.3)'
    },

    bloodDrop: {
        fontSize: '42px'
    },

    impactTitle: {
        margin: '0 0 5px 0',
        color: '#e74c3c',
        fontWeight: '600'
    },

    impactText: {
        color: '#ccc',
        marginBottom: '8px'
    },

    badgeList: {
        display: 'flex',
        gap: '10px',
        flexWrap: 'wrap'
    },

    bloodBadge: {
        backgroundColor: '#e74c3c',
        color: '#fff',
        padding: '6px 14px',
        borderRadius: '16px',
        fontSize: '0.9rem',
        fontWeight: '500'
    },

    profileSummary: {
        backgroundColor: '#1f1f1f',
        padding: '25px',
        borderRadius: '18px',
        marginBottom: '30px',
        boxShadow: '0 6px 18px rgba(0,0,0,0.2)'
    },

    sectionTitle: {
        color: '#e74c3c',
        marginTop: 0,
        fontWeight: '600'
    },

    summaryGrid: {
        display: 'flex',
        gap: '15px',
        flexWrap: 'wrap'
    },

    summaryItem: {
        backgroundColor: '#2a2a2a',
        padding: '12px 18px',
        borderRadius: '12px',
        flex: '1 1 150px',
        textAlign: 'center'
    },

    sectionHeader: {
        borderLeft: '4px solid #e74c3c',
        paddingLeft: '12px',
        marginBottom: '20px',
        fontSize: '1.3rem',
        fontWeight: '500'
    },

    sectionCard: {
        backgroundColor: '#1f1f1f',
        padding: '25px',
        borderRadius: '20px',
        boxShadow: '0 6px 18px rgba(0,0,0,0.25)'
    }
};

export default DonorDashboard;
